# Vinyl Recognition — Android

Proyecto Android Studio que abre https://vinyl-recognition-mu-bcnb.bolt.host en una WebView a pantalla completa y permite el uso del micrófono desde esa web.

## Crear el APK

1. Instala Android Studio en un ordenador.
2. Abre la carpeta `VinylRecognition` con **Open**.
3. Acepta la instalación de Android SDK Platform 35 y espera a que termine la sincronización de Gradle.
4. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio generará el APK en `app/build/outputs/apk/debug/app-debug.apk`.

## Permisos y funcionamiento

- Internet para cargar la web.
- Micrófono solicitado cuando la web intenta capturar audio.
- Solo se concede captura de audio a la URL HTTPS indicada; otras solicitudes se rechazan.
- La web debe implementar captura de audio compatible con Android WebView (`getUserMedia`).

## Nota

Este entorno no incluye Android SDK ni Gradle, por lo que aquí se entrega el proyecto fuente preparado, no un APK compilado. La web puede requerir ajustes propios para funcionar dentro de WebView; el servidor devuelve acceso denegado (HTTP 403) al intentar inspeccionarlo desde este entorno, así que no se ha podido verificar su comportamiento interno.
